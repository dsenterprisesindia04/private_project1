# D.S. ENTERPRISES – Cloudflare Pages order starter

This starter adds a customer order-request form and order tracking to a Cloudflare Pages site using D1.

## Important
- This is an initial order-request system, not the complete business app.
- It does not collect online payments.
- No owner/admin panel is included yet. Do not expose customer data publicly.
- The site needs a Pages Functions deployment and a D1 database binding named `DB`.
- Never add passwords, API keys, bank details, or secret values to public GitHub files.

## Install
1. Replace the repository's `index.html` with this package's `index.html`.
2. Add the `functions` folder and `migrations` folder at the repository root.
3. In Cloudflare D1, open your database and run `migrations/0001_init.sql` in the Console, or apply it with Wrangler:
   `npx wrangler d1 execute ds-enterprises-db --remote --file=migrations/0001_init.sql`
4. In Cloudflare Pages > Settings > Bindings, create a D1 binding:
   - Variable name: `DB`
   - Database: `ds-enterprises-db`
5. Redeploy the Pages project.

## Test
- Open the site, submit a test order with a test phone number.
- Save the generated Order ID.
- Track it with that same phone number.
- If API routes return 404, confirm the `functions` folder is at the repository root and Pages is connected to the correct Git repo/branch.

## Free-tier note
Cloudflare plan limits and terms can change. Free usage is not guaranteed forever. Review the current Cloudflare plan and Pages/D1 limits before relying on it for business records.
