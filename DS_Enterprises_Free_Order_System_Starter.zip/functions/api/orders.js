const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
export async function onRequestPost({request,env}) {
  if(!env.DB) return json({error:"D1 database binding 'DB' नहीं मिला।"},500);
  let b; try{b=await request.json()}catch{return json({error:"गलत अनुरोध।"},400)}
  const product=String(b.product||"").trim(),name=String(b.name||"").trim(),phone=String(b.phone||"").trim(),address=String(b.address||"").trim(),email=String(b.email||"").trim();
  const quantity=Number(b.quantity);
  if(!product||!name||!phone||!address||!Number.isInteger(quantity)||quantity<1||quantity>999) return json({error:"सभी जरूरी जानकारी सही भरें।"},400);
  if(name.length>80||phone.length>15||address.length>500||email.length>120||product.length>100) return json({error:"कुछ जानकारी बहुत लंबी है।"},400);
  const orderId="DS"+Date.now().toString().slice(-9)+Math.floor(Math.random()*90+10);
  try{await env.DB.prepare("INSERT INTO orders (order_id, product, quantity, customer_name, phone, email, address, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending approval', datetime('now'))").bind(orderId,product,quantity,name,phone,email,address).run();return json({ok:true,orderId})}
  catch(e){return json({error:"ऑर्डर सेव नहीं हुआ। Database migration लागू हुई है या नहीं जाँचें।"},500)}
}
export async function onRequestGet({request,env,params}) {
  if(!env.DB) return json({error:"D1 database binding 'DB' नहीं मिला।"},500);
  const orderId=String(params.id||"").trim(),phone=new URL(request.url).searchParams.get("phone")||"";
  if(!orderId||!phone) return json({error:"Order ID और मोबाइल नंबर जरूरी हैं।"},400);
  try{const row=await env.DB.prepare("SELECT order_id,product,quantity,status FROM orders WHERE order_id=? AND phone=?").bind(orderId,phone).first();if(!row)return json({error:"इस जानकारी से ऑर्डर नहीं मिला।"},404);return json({orderId:row.order_id,product:row.product,quantity:row.quantity,status:row.status})}
  catch(e){return json({error:"डेटाबेस से जानकारी नहीं मिली।"},500)}
}